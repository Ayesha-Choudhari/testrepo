import java.util.Scanner;  // Import the Scanner class

class Main {
  public static void main(String[] args) {
    Scanner myObj = new Scanner(System.in);  // Create a Scanner object
    System.out.println("Enter username");

    String x = myObj.next();  // Read user input
    String y = myObj.next();  // Read user input
    System.out.println("Hello " + x +" and "+ y);  // Output user input
    System.out.println("Goodbye " + x +" and "+ y);  // Output user input
 
  }
}

